# ffmpeg scripts for handicaps

This Python 3 module simplifies 2-pass VP9/Opus encoding for AMQ using `ffmpeg`. They are basically all wrappers for ffmpeg.
I'll write it up later. Install it with `pip`:

```sh
pip install amqencode
```

or maybe this on windows

```sh
py -3 -m pip install amqencode
```

then `import amqencode` into your python scripts.
