# ffmpeg scripts for handicaps

These scripts expedite 2-pass VP9/Opus encoding for AMQ using `ffmpeg`. They are basically all wrappers for ffmpeg.

Python module now exists. I'll write it up later
